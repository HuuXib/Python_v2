k = sp.Symbol('k', real = 'True', nonzero=True, positive=True, integer=True)
from sympy import I, pi, exp, integrate, simplify

def oblicz_wspolczynniki_szeregu(funkcja, początek_zakresu, koniec_zakresu):
    F0, Fk = 0, 0
    
    
    kernel = sp.exp(-sp.I*k*2*sp.pi*t/T)
    
    F0 = sp.integrate(funkcja, (t, początek_zakresu, koniec_zakresu))/T
    Fk = sp.integrate(funkcja*kernel, (t, początek_zakresu, koniec_zakresu))/T
    
    return F0, Fk

F0, Fk = oblicz_wspolczynniki_szeregu(f3, 0, T)
display(sp.simplify(F0))
display(sp.simplify(Fk))

range_ = [-N-5, N+6]
k_values = np.arange(range_[0], range_[1], 1)

def oblicz_wartosci_wspolczynnikow(Fk, F0, k_vals):
    Fk_vector = []
    for k_val in k_vals:
        if k_val == 0:
            # k=0 to składowa stała
            Fk_vector.append(float(F0))
        else:
            # Podstawiamy wartość k do wyrażenia Fk
            val = Fk.subs(k, k_val)
            Fk_vector.append(complex(val))
    
    return np.array(Fk_vector)

Fk_vector = oblicz_wartosci_wspolczynnikow(Fk, F0, k_values)

fig, ax = plt.subplots(1, 2)
# Wykres amplitud
amplitudes = np.abs(Fk_vector)
ax[0].stem(k_values, amplitudes)
ax[0].set_title('Widmo amplitudowe |Fk|')
ax[0].set_xlabel('k')
ax[0].set_ylabel('|Fk|')
ax[0].grid(True, alpha=0.3)

# Wykres fazowy
phases = np.angle(Fk_vector)
ax[1].stem(k_values, phases)
ax[1].set_title('Widmo fazowe ∠Fk')
ax[1].set_xlabel('k')
ax[1].set_ylabel('Faza [rad]')
ax[1].grid(True, alpha=0.3)

fig.show()

## Rekonstrukcja (dla wybitnych):