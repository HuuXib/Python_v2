import sympy 
import numpy as np
import matplotlib.pyplot as plt 

#declare symbolic variable t (time) and period (T=1)
t = sympy.Symbol('t', real = 'True', nonzero = 'True') 
plt.rcParams['figure.figsize']=(12, 8)

NumberOfSamples = 1001
A = 1 
T = 1
fa = ((4*T)/A) * t
fb = A
fc = ((-4 * A)/T) * t + T + 3*A

fd = sympy.Piecewise((fa, (t>=0 ) & ( t <=T/4)) , (fb, (t >T/4) & (t <= (3/4)*T)), (fc, (t > (3/4)*T) & (t<=T)))

fd_num = sympy.lambdify(t, fd)
x = np.linspace(-T,T,NumberOfSamples)




fe = (sympy.exp(T/2-t))
fg= (sympy.exp(t-T/2))

fh = sympy.Piecewise((fe, (t>=0 ) & ( t <=T/2)) , (fg, (t >T/2) & (t <=T)))

fh_num = sympy.lambdify(t, fh)
plt.subplot(1,2,1)
plt.plot(x,fh_num(x))
plt.grid()


plt.subplot(1,2,2)
plt.plot(x, fd_num(x))
plt.xticks(
    [0, T/4, T/2, 3*T/4, T],
    ["0", "T/4", "T/2", "3T/4", "T"]
)
plt.yticks([A,3*A/4,A/2,A/4],["A","3A/4","A/2","A/4"])
plt.grid()
plt.show()


